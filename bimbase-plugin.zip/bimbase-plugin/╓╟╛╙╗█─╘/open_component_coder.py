# -*- coding: utf-8 -*-
from embedded_nav import open_embedded

open_embedded("/coder.html", "AI 构件编程")

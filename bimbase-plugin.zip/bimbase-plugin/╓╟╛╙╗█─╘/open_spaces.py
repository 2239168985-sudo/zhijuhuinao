# -*- coding: utf-8 -*-
import sys

PLUGIN_DIRECTORY = r"D:\WorkBuddy\zhijuhuinao\bimbase-plugin\智居慧脑"
if PLUGIN_DIRECTORY not in sys.path:
    sys.path.insert(0, PLUGIN_DIRECTORY)

from embedded_nav import open_embedded

open_embedded("/spaces.html", "空间智能总览")

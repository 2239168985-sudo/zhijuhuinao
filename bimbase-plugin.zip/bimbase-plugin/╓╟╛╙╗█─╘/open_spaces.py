# -*- coding: utf-8 -*-
from embedded_nav import open_embedded

open_embedded("/spaces.html", "空间智能总览")

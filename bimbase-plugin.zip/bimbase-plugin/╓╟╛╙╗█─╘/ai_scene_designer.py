# -*- coding: utf-8 -*-
"""智居慧脑 · AI 场景设计（BIMBase Python 3.7 兼容）。"""

import ctypes
import datetime
import json
import os
import queue
import subprocess
import threading
import urllib.request

from pyp3d import get_all_datakey, get_noumenon_from_datakey, replace_noumenon_python_new


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RUNTIME_DIR = os.path.join(BASE_DIR, "runtime")
DIALOG_PATH = os.path.join(BASE_DIR, "ai_scene_dialog.ps1")
SETTINGS_PATH = os.path.join(BASE_DIR, "ai_scene_settings.json")
REQUEST_PATH = os.path.join(RUNTIME_DIR, "scene_request.json")
UNDO_PATH = os.path.join(RUNTIME_DIR, "last_scene_undo.json")
LOG_PATH = os.path.join(RUNTIME_DIR, "ai_scene.log")

SAFE_WORDS = (
    "开关", "状态", "亮度", "色温", "模式", "目标温度", "温度", "风速",
    "照明", "窗帘", "开启角度", "运行", "充电", "功率", "儿童锁", "柜门", "场景",
)

SCENES = {
    "长者夜间照护": {
        "keywords": ("长者", "老人", "夜间", "起夜", "照护"),
        "rules": (("灯", "亮度", 25), ("灯", "色温", 3000), ("窗帘", "状态", "关闭"),
                  ("空调", "目标温度", 25), ("儿童锁", "状态", "关闭")),
    },
    "儿童学习": {
        "keywords": ("儿童", "孩子", "学习", "作业", "阅读"),
        "rules": (("灯", "亮度", 80), ("灯", "色温", 4500), ("窗帘", "开启角度", 40),
                  ("空调", "目标温度", 24), ("儿童锁", "状态", "开启")),
    },
    "家庭影院": {
        "keywords": ("电影", "影院", "观影", "电视"),
        "rules": (("灯", "亮度", 10), ("窗帘", "状态", "关闭"),
                  ("空调", "目标温度", 24), ("电视", "状态", "开启")),
    },
    "离家节能": {
        "keywords": ("离家", "外出", "节能", "无人"),
        "rules": (("灯", "状态", "关闭"), ("空调", "状态", "关闭"),
                  ("窗帘", "状态", "关闭"), ("充电", "状态", "关闭")),
    },
}


def message(text, title="智居慧脑 · AI场景设计", flags=0x40):
    ctypes.windll.user32.MessageBoxW(None, str(text), title, flags | 0x50000)


def log_event(text):
    try:
        os.makedirs(RUNTIME_DIR, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as stream:
            stream.write("[%s] %s\n" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), text))
    except Exception:
        pass


def ask(text):
    return ctypes.windll.user32.MessageBoxW(None, str(text), "智居慧脑 · 执行确认", 0x50024) == 6


def simple(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    for name in ("value", "_value"):
        try:
            candidate = getattr(value, name)
            if candidate is None or isinstance(candidate, (str, int, float, bool)):
                return candidate
        except Exception:
            pass
    return str(value)


def nou_get(noumenon, key, default=None):
    try:
        return simple(noumenon[key])
    except Exception:
        try:
            return simple(getattr(noumenon, key))
        except Exception:
            return default


def datakey_id(datakey):
    return str(datakey)


def scan_model():
    components = []
    log_event("开始调用 get_all_datakey")
    datakeys = get_all_datakey()
    log_event("get_all_datakey 返回，共 %d 个实例" % len(datakeys))
    for datakey in datakeys[:300]:
        try:
            noumenon = get_noumenon_from_datakey(datakey)
            keys = [str(k) for k in noumenon.keys()]
            values = {key: nou_get(noumenon, key) for key in keys}
            name = str(values.get("名称") or values.get("构件名称") or values.get("Name") or "未命名构件")
            category = str(values.get("类别") or values.get("构件类型") or values.get("Category") or "")
            components.append({
                "datakey": datakey,
                "id": datakey_id(datakey),
                "name": name,
                "category": category,
                "noumenon": noumenon,
                "values": values,
            })
        except Exception:
            continue
    return components


def scan_model_with_timeout(timeout_seconds=6):
    result_queue = queue.Queue()

    def worker():
        try:
            result_queue.put((scan_model(), None))
        except Exception as error:
            result_queue.put(([], str(error)))

    thread = threading.Thread(target=worker, name="bimbase-model-scan")
    thread.daemon = True
    thread.start()
    try:
        components, error = result_queue.get(timeout=timeout_seconds)
        return components, False, error
    except queue.Empty:
        log_event("模型读取超过 %d 秒，切换为即时预览方案" % timeout_seconds)
        return [], True, None


def choose_scene(preset, prompt):
    if preset in SCENES:
        return preset
    text = prompt or ""
    for scene_name, scene in SCENES.items():
        if any(word in text for word in scene["keywords"]):
            return scene_name
    return "长者夜间照护"


def is_safe_parameter(parameter):
    return any(word in str(parameter) for word in SAFE_WORDS)


def local_plan(components, preset, prompt):
    scene_name = choose_scene(preset, prompt)
    actions = []
    for component in components:
        searchable = (component["name"] + " " + component["category"]).lower()
        for target_word, parameter_word, value in SCENES[scene_name]["rules"]:
            if target_word.lower() not in searchable:
                continue
            matches = [key for key in component["values"] if parameter_word in key and is_safe_parameter(key)]
            if not matches and parameter_word == "状态":
                matches = [key for key in component["values"] if "开关" in key and is_safe_parameter(key)]
            if matches:
                parameter = matches[0]
                actions.append({
                    "component_id": component["id"],
                    "component_name": component["name"],
                    "parameter": parameter,
                    "old_value": component["values"].get(parameter),
                    "value": value,
                    "reason": scene_name,
                })
    return {"scene": scene_name, "source": "本地场景规则", "summary": prompt, "actions": actions}


def preview_plan(preset, prompt, reason):
    scene_name = choose_scene(preset, prompt)
    actions = []
    for target_word, parameter, value in SCENES[scene_name]["rules"]:
        actions.append({
            "component_id": "",
            "component_name": target_word + "类智能构件",
            "parameter": parameter,
            "old_value": "等待 BIM 匹配",
            "value": value,
            "reason": scene_name,
        })
    return {
        "scene": scene_name,
        "source": "AI 场景建议 · 即时预览",
        "summary": prompt,
        "actions": actions,
        "preview_only": True,
        "fallback_reason": reason,
    }


def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8-sig") as stream:
            return json.load(stream)
    except Exception:
        return {}


def online_plan(components, preset, prompt):
    settings = load_settings()
    endpoint = str(settings.get("endpoint") or "").strip()
    model = str(settings.get("model") or "").strip()
    api_key = str(settings.get("api_key") or "").strip()
    if not endpoint or not model or not api_key:
        return None

    context = []
    for component in components[:150]:
        safe_values = {k: v for k, v in component["values"].items() if is_safe_parameter(k)}
        if safe_values:
            context.append({"id": component["id"], "name": component["name"], "parameters": safe_values})
    instruction = (
        "你是BIM智慧住宅场景规划器。只返回JSON对象，字段为scene、summary、actions。"
        "actions每项只能使用给定component_id和已有parameter，字段为component_id、parameter、value、reason。"
        "不得创建或删除构件。用户需求：%s；预设：%s；BIM构件：%s"
        % (prompt, preset, json.dumps(context, ensure_ascii=False))
    )
    body = json.dumps({"model": model, "messages": [{"role": "user", "content": instruction}], "temperature": 0.2}).encode("utf-8")
    request = urllib.request.Request(endpoint, data=body, headers={
        "Authorization": "Bearer " + api_key,
        "Content-Type": "application/json",
    })
    with urllib.request.urlopen(request, timeout=35) as response:
        result = json.loads(response.read().decode("utf-8"))
    content = result["choices"][0]["message"]["content"].strip()
    if content.startswith("```"):
        content = content.strip("`").replace("json\n", "", 1)
    plan = json.loads(content)
    plan["source"] = "在线大语言模型"
    return plan


def normalize_plan(plan, components):
    by_id = {item["id"]: item for item in components}
    actions = []
    for action in plan.get("actions", []):
        component = by_id.get(str(action.get("component_id")))
        parameter = str(action.get("parameter") or "")
        if not component or parameter not in component["values"] or not is_safe_parameter(parameter):
            continue
        actions.append({
            "component_id": component["id"],
            "component_name": component["name"],
            "parameter": parameter,
            "old_value": component["values"].get(parameter),
            "value": action.get("value"),
            "reason": action.get("reason") or plan.get("scene") or "AI建议",
        })
    plan["actions"] = actions
    return plan


def plan_text(plan, component_count):
    action_label = "建议调整" if plan.get("preview_only") else "可执行调整"
    lines = [
        "方案：%s" % plan.get("scene", "自定义场景"),
        "规划来源：%s" % plan.get("source", "本地场景规则"),
        "已读取 BIMBase 构件：%d 个" % component_count,
        "%s：%d 项" % (action_label, len(plan.get("actions", []))),
        "",
    ]
    for index, action in enumerate(plan.get("actions", [])[:18], 1):
        lines.append("%d. %s / %s：%s → %s" % (
            index, action["component_name"], action["parameter"],
            action.get("old_value"), action.get("value")))
    if len(plan.get("actions", [])) > 18:
        lines.append("……另有 %d 项" % (len(plan["actions"]) - 18))
    return "\n".join(lines)


def apply_plan(plan, components):
    by_id = {item["id"]: item for item in components}
    undo = []
    applied = 0
    errors = []
    for action in plan.get("actions", []):
        component = by_id.get(action["component_id"])
        if component is None:
            continue
        try:
            replace_noumenon_python_new(
                {action["parameter"]: action["value"]}, component["datakey"])
            undo.append({
                "component_id": component["id"],
                "parameter": action["parameter"],
                "value": action.get("old_value"),
            })
            applied += 1
        except Exception as exc:
            errors.append("%s/%s: %s" % (component["name"], action["parameter"], exc))
    if undo:
        with open(UNDO_PATH, "w", encoding="utf-8") as stream:
            json.dump({"actions": undo}, stream, ensure_ascii=False, indent=2)
    return applied, errors


def undo_last(components):
    if not os.path.exists(UNDO_PATH):
        message("没有可撤销的场景执行记录。", flags=0x30)
        return
    with open(UNDO_PATH, "r", encoding="utf-8-sig") as stream:
        record = json.load(stream)
    by_id = {item["id"]: item for item in components}
    restored = 0
    for action in record.get("actions", []):
        component = by_id.get(str(action.get("component_id")))
        if component is None:
            continue
        try:
            replace_noumenon_python_new(
                {action["parameter"]: action.get("value")}, component["datakey"])
            restored += 1
        except Exception:
            pass
    os.remove(UNDO_PATH)
    message("已撤销上次场景执行，共恢复 %d 项参数。" % restored)


def run_dialog():
    if os.path.exists(REQUEST_PATH):
        os.remove(REQUEST_PATH)
    command = [
        "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-File", DIALOG_PATH, "-OutputPath", REQUEST_PATH,
    ]
    log_event("启动场景设计窗口")
    # CREATE_NO_WINDOW 只隐藏 PowerShell 控制台，不会把 WinForms 界面一起隐藏。
    result = subprocess.call(command, creationflags=subprocess.CREATE_NO_WINDOW)
    log_event("场景设计窗口结束，返回码=%s" % result)
    if not os.path.exists(REQUEST_PATH):
        return None
    with open(REQUEST_PATH, "r", encoding="utf-8-sig") as stream:
        return json.load(stream)


def main():
    os.makedirs(RUNTIME_DIR, exist_ok=True)
    log_event("AI场景设计插件启动")
    if not os.path.exists(DIALOG_PATH):
        message("缺少界面文件：\n" + DIALOG_PATH, flags=0x10)
        return
    request_data = run_dialog()
    if not request_data:
        return
    message(
        "已接收场景需求。\n\n正在读取当前 BIMBase 模型并匹配智能构件，最多等待 6 秒。",
        title="智居慧脑 · 正在生成方案",
    )
    components, timed_out, scan_error = scan_model_with_timeout(6)
    if request_data.get("action") == "undo":
        undo_last(components)
        return
    if not components:
        reason = "BIMBase 全量构件接口读取超时" if timed_out else (
            "模型读取失败：%s" % scan_error if scan_error else "未发现可匹配的智能构件")
        plan = preview_plan(
            str(request_data.get("preset") or "自动识别"),
            str(request_data.get("prompt") or "").strip(),
            reason,
        )
        message(
            plan_text(plan, 0) +
            "\n\n模型反馈：%s。\n本次已生成可展示的 AI 场景预览，尚未写入模型。" % reason,
            title="智居慧脑 · 场景方案已生成",
            flags=0x40,
        )
        return

    prompt = str(request_data.get("prompt") or "").strip()
    preset = str(request_data.get("preset") or "自动识别")
    plan = None
    if request_data.get("use_online"):
        try:
            plan = online_plan(components, preset, prompt)
        except Exception as exc:
            message("在线模型暂不可用，将使用本地场景规则。\n\n%s" % exc, flags=0x30)
    if plan is None:
        plan = local_plan(components, preset, prompt)
    plan = normalize_plan(plan, components)
    if not plan.get("actions"):
        plan = preview_plan(preset, prompt, "已读取模型，但没有匹配到状态类智能参数")
        message(plan_text(plan, len(components)) +
                "\n\n模型反馈：没有匹配到可安全写入的状态参数。\n本次为预览方案，未修改模型。",
                title="智居慧脑 · 场景方案已生成", flags=0x40)
        return
    preview = plan_text(plan, len(components))
    if not ask(preview + "\n\n是否将以上方案写入当前 BIMBase 模型？"):
        return
    applied, errors = apply_plan(plan, components)
    result = "场景已执行：成功修改 %d 项参数。\n可再次打开插件并选择‘撤销上次执行’。" % applied
    if errors:
        result += "\n\n未完成 %d 项：\n%s" % (len(errors), "\n".join(errors[:6]))
    message(result, flags=0x40 if not errors else 0x30)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        log_event("插件运行失败：%s" % error)
        message("插件运行失败：\n%s" % error, flags=0x10)

# -*- coding: utf-8 -*-
"""向 BIMBase 内的智居慧脑 WebView2 面板发送导航请求。"""

import ctypes
import os
import time


BRIDGE_RUNTIME = r"D:\WorkBuddy\zhijuhuinao\bimbase-plugin-csharp\runtime"
NAVIGATION_PATH = os.path.join(BRIDGE_RUNTIME, "embedded-navigation.txt")
READY_PATH = os.path.join(BRIDGE_RUNTIME, "embedded-panel.ready")


def _message(text, title="智居慧脑 · 内嵌网页", icon=0x40):
    ctypes.windll.user32.MessageBoxW(None, str(text), title, icon | 0x50000)


def open_embedded(route, title):
    try:
        os.makedirs(BRIDGE_RUNTIME, exist_ok=True)
        temporary = NAVIGATION_PATH + ".tmp"
        with open(temporary, "w", encoding="utf-8") as stream:
            stream.write(str(route) + "\n" + str(time.time()))
        os.replace(temporary, NAVIGATION_PATH)

        if os.path.exists(READY_PATH):
            _message("已在 BIMBase 左侧内嵌面板打开：\n" + title)
        else:
            _message(
                "导航请求已发送，但内嵌面板尚未就绪。\n\n"
                "请保存模型并完全重启 BIMBase；重启后面板会自动显示。",
                icon=0x30,
            )
    except Exception as error:
        _message("无法发送内嵌网页导航请求：\n" + str(error), icon=0x10)

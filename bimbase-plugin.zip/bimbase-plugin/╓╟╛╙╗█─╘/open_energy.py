# -*- coding: utf-8 -*-
from embedded_nav import open_embedded

open_embedded("/energy.html", "AI 能源看板")

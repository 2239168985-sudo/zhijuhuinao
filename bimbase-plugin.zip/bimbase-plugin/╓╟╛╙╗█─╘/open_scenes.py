# -*- coding: utf-8 -*-
from embedded_nav import open_embedded

open_embedded("/scenes.html", "智能场景中心")

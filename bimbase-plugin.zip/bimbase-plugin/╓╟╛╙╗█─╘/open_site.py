# -*- coding: utf-8 -*-
from embedded_nav import open_embedded

open_embedded("/", "智居慧脑首页")

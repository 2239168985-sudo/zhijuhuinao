﻿param([Parameter(Mandatory = $true)][string]$OutputPath)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = '智居慧脑 · AI 场景设计'
$form.Size = New-Object System.Drawing.Size(620, 520)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.TopMost = $true
$form.BackColor = [System.Drawing.Color]::FromArgb(245, 248, 250)
$form.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'AI × BIMBase 智能场景编排'
$title.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 18, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(18, 107, 107)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(28, 24)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = '读取当前模型构件与参数，生成可预览、可撤销的空间场景方案'
$subtitle.AutoSize = $true
$subtitle.ForeColor = [System.Drawing.Color]::FromArgb(85, 95, 105)
$subtitle.Location = New-Object System.Drawing.Point(31, 68)
$form.Controls.Add($subtitle)

$presetLabel = New-Object System.Windows.Forms.Label
$presetLabel.Text = '场景预设'
$presetLabel.AutoSize = $true
$presetLabel.Location = New-Object System.Drawing.Point(31, 112)
$form.Controls.Add($presetLabel)

$preset = New-Object System.Windows.Forms.ComboBox
$preset.DropDownStyle = 'DropDownList'
$preset.Items.AddRange(@('自动识别', '长者夜间照护', '儿童学习', '家庭影院', '离家节能'))
$preset.SelectedIndex = 0
$preset.Location = New-Object System.Drawing.Point(34, 138)
$preset.Size = New-Object System.Drawing.Size(536, 32)
$form.Controls.Add($preset)

$promptLabel = New-Object System.Windows.Forms.Label
$promptLabel.Text = '用自然语言描述需求'
$promptLabel.AutoSize = $true
$promptLabel.Location = New-Object System.Drawing.Point(31, 190)
$form.Controls.Add($promptLabel)

$prompt = New-Object System.Windows.Forms.TextBox
$prompt.Multiline = $true
$prompt.ScrollBars = 'Vertical'
$prompt.Location = New-Object System.Drawing.Point(34, 217)
$prompt.Size = New-Object System.Drawing.Size(536, 116)
$prompt.Text = '夜间有人起床时打开低亮度暖光，关闭窗帘，并将室温保持在舒适范围。'
$form.Controls.Add($prompt)

$online = New-Object System.Windows.Forms.CheckBox
$online.Text = '优先使用已配置的在线大语言模型（不可用时自动回退本地规则）'
$online.AutoSize = $true
$online.Location = New-Object System.Drawing.Point(34, 352)
$form.Controls.Add($online)

$note = New-Object System.Windows.Forms.Label
$note.Text = '安全策略：仅修改已存在的状态类参数；执行前展示方案并再次确认。'
$note.AutoSize = $true
$note.ForeColor = [System.Drawing.Color]::FromArgb(105, 115, 125)
$note.Location = New-Object System.Drawing.Point(31, 384)
$form.Controls.Add($note)

$run = New-Object System.Windows.Forms.Button
$run.Text = '生成场景方案'
$run.Size = New-Object System.Drawing.Size(142, 42)
$run.Location = New-Object System.Drawing.Point(428, 420)
$run.BackColor = [System.Drawing.Color]::FromArgb(23, 151, 151)
$run.ForeColor = [System.Drawing.Color]::White
$run.FlatStyle = 'Flat'
$run.Add_Click({
    $run.Enabled = $false
    $undo.Enabled = $false
    $cancel.Enabled = $false
    $run.Text = '正在提交...'
    $note.Text = '需求已接收，正在启动 BIMBase 模型分析，请稍候。'
    $note.ForeColor = [System.Drawing.Color]::FromArgb(18, 107, 107)
    $form.Refresh()
    try {
        $parent = Split-Path -Parent $OutputPath
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
        $data = [ordered]@{ action = 'plan'; preset = [string]$preset.SelectedItem; prompt = $prompt.Text; use_online = [bool]$online.Checked }
        [System.IO.File]::WriteAllText($OutputPath, ($data | ConvertTo-Json), (New-Object System.Text.UTF8Encoding($false)))
        Start-Sleep -Milliseconds 350
        $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $form.Close()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show('提交需求失败：' + $_.Exception.Message, '智居慧脑', 'OK', 'Error') | Out-Null
        $run.Text = '生成场景方案'
        $run.Enabled = $true
        $undo.Enabled = $true
        $cancel.Enabled = $true
    }
})
$form.Controls.Add($run)

$undo = New-Object System.Windows.Forms.Button
$undo.Text = '撤销上次执行'
$undo.Size = New-Object System.Drawing.Size(142, 42)
$undo.Location = New-Object System.Drawing.Point(184, 420)
$undo.Add_Click({
    $parent = Split-Path -Parent $OutputPath
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    [System.IO.File]::WriteAllText($OutputPath, '{"action":"undo"}', (New-Object System.Text.UTF8Encoding($false)))
    $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Close()
})
$form.Controls.Add($undo)

$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = '取消'
$cancel.Size = New-Object System.Drawing.Size(126, 42)
$cancel.Location = New-Object System.Drawing.Point(34, 420)
$cancel.Add_Click({ $form.Close() })
$form.Controls.Add($cancel)

$form.AcceptButton = $run
$form.CancelButton = $cancel
$form.Add_Shown({
    $form.Activate()
    $form.BringToFront()
})
[void]$form.ShowDialog()

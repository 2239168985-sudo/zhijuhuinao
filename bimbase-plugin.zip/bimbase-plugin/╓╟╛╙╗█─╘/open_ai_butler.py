# -*- coding: utf-8 -*-
from embedded_nav import open_embedded

open_embedded("/butler.html", "AI 居家管家")

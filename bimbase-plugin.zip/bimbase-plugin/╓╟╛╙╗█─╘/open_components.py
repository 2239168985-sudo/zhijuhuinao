# -*- coding: utf-8 -*-
"""在 Windows 默认浏览器中打开智居慧脑参数化构件库。"""
import ctypes


URL = "https://2239168985-sudo.github.io/zhijuhuinao/components.html"


def open_external(url):
    shell_execute = ctypes.windll.shell32.ShellExecuteW
    shell_execute.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p,
                              ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_int]
    shell_execute.restype = ctypes.c_void_p
    result = int(shell_execute(None, "open", url, None, None, 1) or 0)
    if result <= 32:
        ctypes.windll.user32.MessageBoxW(
            None,
            "无法调用默认浏览器，请手动访问：\n" + url,
            "智居慧脑 · 构件库总览",
            0x10 | 0x50000,
        )


open_external(URL)

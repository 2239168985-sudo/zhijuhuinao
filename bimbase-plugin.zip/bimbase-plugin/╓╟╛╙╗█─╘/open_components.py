# -*- coding: utf-8 -*-
from embedded_nav import open_embedded

open_embedded("/components.html", "参数化构件库")

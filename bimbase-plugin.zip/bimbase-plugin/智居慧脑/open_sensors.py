# -*- coding: utf-8 -*-
"""扫描 BIMBase 传感器实例，生成 AI 融合分析仪表盘并在左侧内嵌显示。"""
import copy
import ctypes
import datetime
import json
import os
import re
import sys
import time


PLUGIN_DIRECTORY = r"D:\WorkBuddy\zhijuhuinao\bimbase-plugin\智居慧脑"
RUNTIME_DIRECTORY = r"D:\WorkBuddy\zhijuhuinao\bimbase-plugin-csharp\runtime"
EXPORT_DIRECTORY = r"D:\WorkBuddy\zhijuhuinao\exports"
HTML_PATH = os.path.join(EXPORT_DIRECTORY, "sensor-ai-dashboard.html")
JSON_PATH = os.path.join(EXPORT_DIRECTORY, "sensor-ai-data.json")
LOG_PATH = os.path.join(RUNTIME_DIRECTORY, "sensor-dashboard.log")
if PLUGIN_DIRECTORY not in sys.path:
    sys.path.insert(0, PLUGIN_DIRECTORY)


SENSOR_CATALOG = [
    {
        "code": "SEN-01", "name": "六合一环境传感器", "kind": "环境融合", "floor": "f2", "space": "主卧",
        "state": "舒适", "source": "构件库参考", "ai": "融合温湿度与气压，识别闷热、干燥和睡眠舒适度变化。",
        "metrics": [
            {"label": "温度", "unit": "℃", "value": 24.2, "keys": ["温度", "当前温度"]},
            {"label": "湿度", "unit": "%", "value": 53, "keys": ["湿度", "当前湿度"]},
            {"label": "气压", "unit": "hPa", "value": 1008, "keys": ["气压", "当前气压"]},
        ], "trend": [42, 45, 44, 49, 53, 51, 56, 54]
    },
    {
        "code": "SEN-02", "name": "智能光电感烟探测器", "kind": "消防安全", "floor": "f2", "space": "二层走廊",
        "state": "正常", "source": "构件库参考", "ai": "结合浓度斜率和干扰甄别，降低蒸汽与粉尘造成的误报。",
        "metrics": [
            {"label": "烟雾浓度", "unit": "%obs/m", "value": 0.03, "keys": ["烟雾浓度", "当前烟雾"]},
            {"label": "预警阈值", "unit": "%", "value": 0.12, "keys": ["预警阈值"]},
        ], "trend": [9, 10, 9, 11, 10, 12, 11, 10]
    },
    {
        "code": "SEN-03", "name": "厨房智能可燃气体泄漏探测器", "kind": "燃气安全", "floor": "f1", "space": "厨房",
        "state": "正常", "source": "构件库参考", "ai": "分析燃气浓度、增长速度与烹饪状态，决定是否关阀、排风和通知。",
        "metrics": [
            {"label": "天然气浓度", "unit": "%LEL", "value": 0.8, "keys": ["天然气浓度", "燃气浓度"]},
            {"label": "检测灵敏度", "unit": "%", "value": 92, "keys": ["检测灵敏度"]},
        ], "trend": [8, 9, 10, 9, 11, 12, 11, 10]
    },
    {
        "code": "SEN-04", "name": "智能岛式油烟机", "kind": "空气感知", "floor": "f1", "space": "厨房",
        "state": "自动巡航", "source": "构件库参考", "ai": "根据油烟浓度与增长趋势预测峰值，提前调整风量并兼顾噪声。",
        "metrics": [
            {"label": "油烟指数", "unit": "AQI", "value": 18, "keys": ["当前烟雾", "空气质量"]},
            {"label": "滤网寿命", "unit": "%", "value": 86, "keys": ["滤网寿命"]},
        ], "trend": [18, 22, 26, 20, 17, 24, 21, 18]
    },
    {
        "code": "SEN-05", "name": "毫米波人体存在传感器", "kind": "行为感知", "floor": "f2", "space": "家庭起居区",
        "state": "检测到 1 人", "source": "构件库参考", "ai": "连续识别存在、微动和停留时长，为老人照护与无人节能提供证据。",
        "metrics": [
            {"label": "检测目标", "unit": "人", "value": 1, "keys": ["检测目标数"]},
            {"label": "信号强度", "unit": "%", "value": 88, "keys": ["信号强度"]},
            {"label": "环境照度", "unit": "lx", "value": 126, "keys": ["环境照度"]},
        ], "trend": [22, 28, 48, 62, 75, 68, 72, 70]
    },
    {
        "code": "SEN-06", "name": "水浸传感器", "kind": "漏水安全", "floor": "f2", "space": "卫生间",
        "state": "干燥", "source": "构件库参考", "ai": "结合积水等级、位置和持续时间，区分溅水与持续泄漏。",
        "metrics": [
            {"label": "积水深度", "unit": "mm", "value": 0, "keys": ["积水等级", "积水深度"]},
            {"label": "电池电量", "unit": "%", "value": 93, "keys": ["电池电量"]},
        ], "trend": [4, 4, 5, 4, 4, 5, 4, 4]
    },
    {
        "code": "SEN-07", "name": "客厅窗边自然光传感器", "kind": "光环境", "floor": "f1", "space": "客厅窗边",
        "state": "阴天", "source": "构件库参考", "ai": "结合自然光变化、时段和人员活动，优化窗帘与照明能耗。",
        "metrics": [
            {"label": "光照强度", "unit": "lx", "value": 318, "keys": ["光照强度", "环境照度"]},
            {"label": "检测精度", "unit": "%", "value": 96, "keys": ["检测精度"]},
        ], "trend": [28, 35, 46, 55, 62, 68, 64, 59]
    },
]


def log_event(text):
    try:
        os.makedirs(RUNTIME_DIRECTORY, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as stream:
            stream.write("[{}] {}\n".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), text))
    except Exception:
        pass


def text_value(value):
    if value is None:
        return ""
    try:
        if hasattr(value, "value"):
            value = value.value
    except Exception:
        pass
    return str(value)


def first_value(noumenon, names):
    for name in names:
        try:
            value = noumenon.get(name, "")
        except Exception:
            try:
                value = noumenon[name]
            except Exception:
                value = ""
        value = text_value(value).strip()
        if value:
            return value
    return ""


def number_value(value, fallback):
    match = re.search(r"-?\d+(?:\.\d+)?", text_value(value))
    return float(match.group(0)) if match else fallback


def detect_catalog(identity):
    rules = [
        ("SEN-03", ["可燃气", "燃气泄漏", "天然气浓度"]),
        ("SEN-02", ["感烟", "烟雾浓度", "光电烟"]),
        ("SEN-06", ["水浸", "漏水状态", "积水等级"]),
        ("SEN-05", ["毫米波", "人体存在", "检测目标数"]),
        ("SEN-07", ["自然光传感", "光照强度"]),
        ("SEN-01", ["六合一环境", "气压", "温度湿度"]),
        ("SEN-04", ["油烟机", "油烟指数", "当前烟雾"]),
    ]
    for code, words in rules:
        if code in identity or any(word in identity for word in words):
            return next(item for item in SENSOR_CATALOG if item["code"] == code)
    return None


def infer_floor(space, fallback):
    text = text_value(space)
    if "三层" in text or "书房" in text or "家政" in text or "设备间" in text:
        return "f3"
    if "二层" in text or "主卧" in text or "次卧" in text or "儿童房" in text or "卫生间" in text:
        return "f2"
    if "一层" in text or "厨房" in text or "客厅" in text or "餐厅" in text or "玄关" in text:
        return "f1"
    if "庭院" in text or "室外" in text:
        return "yard"
    return fallback


def sensor_from_model(noumenon, catalog, instance_index):
    sensor = copy.deepcopy(catalog)
    name = first_value(noumenon, ["构件名称", "名称", "Name", "schemaName"])
    location = first_value(noumenon, ["房间", "空间", "安装房间", "检测位置", "安装表面", "安装位置说明"])
    sensor["name"] = name or sensor["name"]
    sensor["space"] = location or sensor["space"]
    sensor["floor"] = infer_floor(sensor["space"], sensor["floor"])
    sensor["source"] = "BIMBase 实例"
    sensor["instance"] = "{}-{:02d}".format(sensor["code"], instance_index)

    for metric in sensor["metrics"]:
        raw = first_value(noumenon, metric.get("keys", []))
        if raw:
            metric["value"] = number_value(raw, metric["value"])

    state_keys = {
        "SEN-01": ["环境状态", "系统模式"], "SEN-02": ["工作状态", "报警状态"],
        "SEN-03": ["燃气状态", "报警状态"], "SEN-04": ["运行反馈", "空气质量"],
        "SEN-05": ["人体检测状态", "活动等级"], "SEN-06": ["漏水状态", "积水等级"],
        "SEN-07": ["环境状态", "自然光状态"],
    }
    state = first_value(noumenon, state_keys.get(sensor["code"], []))
    if state:
        sensor["state"] = state
    return sensor


def risk_for(sensor):
    code = sensor["code"]
    values = [float(metric.get("value", 0)) for metric in sensor["metrics"]]
    state = text_value(sensor.get("state", ""))
    if code == "SEN-03" and (values[0] >= 8 or "报警" in state or "泄漏" in state):
        return "critical"
    if code == "SEN-02" and (values[0] >= 0.12 or "报警" in state):
        return "critical"
    if code == "SEN-06" and (values[0] >= 3 or "漏水" in state or "积水" in state):
        return "warning"
    if code == "SEN-01" and (values[0] < 18 or values[0] > 29 or values[1] < 30 or values[1] > 70):
        return "warning"
    return "normal"


def scan_model_sensors(time_budget=3.0):
    instances = []
    try:
        import pyp3d
        get_all_datakey = getattr(pyp3d, "get_all_datakey", None)
        fast_reader = getattr(pyp3d, "get_noumKV_from_instancekey", None)
        if not callable(get_all_datakey):
            raise RuntimeError("当前 BIMBase 未提供 get_all_datakey")
        if not callable(fast_reader):
            log_event("当前 BIMBase 未提供快速属性接口，跳过阻塞式全模型读取")
            raise RuntimeError("快速属性接口不可用")

        counters = {}
        errors = 0
        inspected = 0
        started = time.time()
        datakeys = get_all_datakey() or []
        for datakey in datakeys:
            if time.time() - started >= time_budget:
                log_event("实时扫描达到 {:.1f} 秒上限，已检查 {}/{} 个实例".format(
                    time_budget, inspected, len(datakeys)))
                break
            inspected += 1
            try:
                # 读取原始键值，不触发构件 Python 模块导入；缺失构件模块也不会拖慢按钮。
                noumenon = fast_reader(datakey)
                if isinstance(noumenon, (list, tuple)):
                    try:
                        noumenon = dict(noumenon)
                    except Exception:
                        pass
                identity = " ".join([
                    first_value(noumenon, ["构件名称", "名称", "Name", "schemaName"]),
                    first_value(noumenon, ["构件编号", "构件编码", "Code"]),
                    first_value(noumenon, ["构件类别", "BIM_Category", "Category"]),
                    " ".join(text_value(key) for key in getattr(noumenon, "keys", lambda: [])()),
                ])
                catalog = detect_catalog(identity)
                if not catalog:
                    continue
                counters[catalog["code"]] = counters.get(catalog["code"], 0) + 1
                instances.append(sensor_from_model(noumenon, catalog, counters[catalog["code"]]))
            except Exception:
                errors += 1
        log_event("BIMBase 快速扫描完成：检查 {} 个实例，识别 {} 个传感器，跳过 {} 个异常".format(
            inspected, len(instances), errors))
    except Exception as error:
        log_event("无法连接 BIMBase 模型接口，使用构件库参考数据：" + str(error))

    present_codes = set(item["code"] for item in instances)
    for catalog in SENSOR_CATALOG:
        if catalog["code"] not in present_codes:
            reference = copy.deepcopy(catalog)
            reference["instance"] = catalog["code"] + "-REF"
            instances.append(reference)

    for sensor in instances:
        sensor["risk"] = risk_for(sensor)
        for metric in sensor["metrics"]:
            metric.pop("keys", None)
    return instances


def build_payload(sensors):
    real_count = len([item for item in sensors if item["source"] == "BIMBase 实例"])
    warning_count = len([item for item in sensors if item["risk"] != "normal"])
    return {
        "generatedAt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "dataMode": "BIMBase 实时实例 + 构件库补全" if real_count else "构件库演示数据",
        "realCount": real_count,
        "total": len(sensors),
        "warningCount": warning_count,
        "aiConfidence": 96,
        "sensors": sensors,
    }


HTML_TEMPLATE = r'''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>智居慧脑 · AI传感器总览</title>
<style>
:root{--bg:#071119;--panel:#0d1d27;--panel2:#102631;--line:rgba(126,231,215,.13);--text:#effcf9;--muted:#8ca9ab;--cyan:#3de5cf;--blue:#4c9cff;--green:#65eba8;--amber:#ffc76a;--red:#ff647c}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% -10%,#133843 0,transparent 38%),var(--bg);color:var(--text);font-family:"Microsoft YaHei","Segoe UI",sans-serif;min-height:100vh}.app{padding:20px;max-width:1480px;margin:auto}.hero{position:relative;overflow:hidden;border:1px solid var(--line);border-radius:24px;padding:24px;background:linear-gradient(135deg,rgba(14,45,55,.98),rgba(8,23,32,.96));box-shadow:0 22px 70px rgba(0,0,0,.28)}.hero:after{content:"";position:absolute;width:260px;height:260px;border-radius:50%;right:-80px;top:-120px;background:rgba(61,229,207,.13);filter:blur(4px)}.topline,.hero-main,.toolbar,.card-head,.metric,.ai-title,.status-row{display:flex;align-items:center}.topline{justify-content:space-between;gap:12px}.brand{letter-spacing:.18em;font-size:11px;color:var(--cyan);font-weight:700}.live{font-size:11px;color:var(--green);padding:6px 10px;border:1px solid rgba(101,235,168,.25);border-radius:99px;background:rgba(101,235,168,.07)}.dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:currentColor;margin-right:6px;box-shadow:0 0 12px currentColor;animation:pulse 1.8s infinite}.hero-main{position:relative;z-index:1;justify-content:space-between;gap:28px;margin-top:28px}.hero h1{font-size:clamp(28px,4vw,48px);line-height:1.08;margin:0 0 12px;letter-spacing:-.04em}.hero h1 span{color:var(--cyan)}.hero p{color:#b9ced0;max-width:710px;line-height:1.8;margin:0;font-size:14px}.kpis{display:grid;grid-template-columns:repeat(3,minmax(100px,1fr));gap:10px;min-width:390px}.kpi{padding:14px;border:1px solid var(--line);border-radius:16px;background:rgba(5,19,26,.62)}.kpi b{display:block;font-size:26px;color:var(--cyan);margin-bottom:4px}.kpi span{font-size:11px;color:var(--muted)}.chain{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:20px}.chain div{padding:11px 12px;border-radius:12px;background:rgba(255,255,255,.035);color:#c5d8d9;font-size:12px}.chain b{color:var(--cyan);margin-right:6px}.toolbar{justify-content:space-between;gap:12px;margin:18px 0 14px;flex-wrap:wrap}.filters{display:flex;gap:7px;flex-wrap:wrap}.btn{border:1px solid var(--line);background:var(--panel);color:var(--muted);border-radius:10px;padding:9px 12px;font-size:12px;cursor:pointer}.btn.active{background:rgba(61,229,207,.13);color:var(--cyan);border-color:rgba(61,229,207,.38)}.btn-alert{color:var(--amber);border-color:rgba(255,199,106,.3);background:rgba(255,199,106,.07)}.layout{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:14px}.sensor-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.sensor{border:1px solid var(--line);border-radius:18px;background:linear-gradient(145deg,var(--panel),#0a1720);padding:16px;min-width:0;transition:.2s}.sensor:hover{transform:translateY(-2px);border-color:rgba(61,229,207,.3)}.sensor.warning{border-color:rgba(255,199,106,.42)}.sensor.critical{border-color:rgba(255,100,124,.55);box-shadow:0 0 30px rgba(255,100,124,.08)}.card-head{justify-content:space-between;gap:10px}.identity{min-width:0}.identity small{color:var(--cyan);font-weight:700}.identity h3{font-size:15px;margin:4px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.identity p{font-size:11px;color:var(--muted);margin:0}.risk{font-size:10px;padding:5px 8px;border-radius:99px;color:var(--green);background:rgba(101,235,168,.09)}.warning .risk{color:var(--amber);background:rgba(255,199,106,.1)}.critical .risk{color:var(--red);background:rgba(255,100,124,.12)}.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:15px 0}.metric{align-items:flex-end;gap:4px;padding:10px;border-radius:12px;background:rgba(255,255,255,.035);min-width:0}.metric b{font-size:18px;white-space:nowrap}.metric em{font-size:9px;color:var(--muted);font-style:normal;margin-bottom:3px}.metric span{display:block;font-size:9px;color:var(--muted);position:absolute;transform:translateY(-28px)}.bars{height:32px;display:flex;gap:3px;align-items:flex-end;padding:0 2px}.bars i{flex:1;min-width:4px;border-radius:3px 3px 1px 1px;background:linear-gradient(var(--cyan),rgba(76,156,255,.35));opacity:.72}.status-row{justify-content:space-between;gap:12px;padding-top:12px;border-top:1px solid var(--line);font-size:10px;color:var(--muted)}.status-row strong{color:#dcebea}.ai-panel{border:1px solid rgba(61,229,207,.2);border-radius:20px;background:linear-gradient(180deg,#102832,#0a171f);padding:17px;position:sticky;top:14px;height:max-content}.ai-title{gap:10px}.ai-orb{width:38px;height:38px;border-radius:13px;background:linear-gradient(135deg,var(--cyan),var(--blue));display:grid;place-items:center;color:#061117;font-weight:900;box-shadow:0 0 28px rgba(61,229,207,.22)}.ai-title h2{font-size:16px;margin:0}.ai-title p{font-size:10px;color:var(--muted);margin:3px 0 0}.score{margin:18px 0;padding:16px;border:1px solid var(--line);border-radius:16px;background:rgba(3,13,18,.45)}.score-line{display:flex;justify-content:space-between;font-size:11px;color:var(--muted)}.score strong{font-size:32px;color:var(--green)}.meter{height:6px;border-radius:99px;background:#18313a;overflow:hidden;margin-top:10px}.meter i{display:block;height:100%;width:96%;background:linear-gradient(90deg,var(--blue),var(--green));border-radius:inherit}.insight{padding:13px;border-radius:14px;background:rgba(61,229,207,.07);border:1px solid rgba(61,229,207,.12);font-size:12px;line-height:1.7;color:#cfe4e3}.insight.alert{background:rgba(255,100,124,.08);border-color:rgba(255,100,124,.23)}.events{margin-top:16px}.events h3{font-size:12px;margin:0 0 10px}.event{position:relative;padding:0 0 13px 18px;border-left:1px solid #24404a;margin-left:4px;font-size:10px;color:var(--muted)}.event:before{content:"";position:absolute;left:-4px;top:2px;width:7px;height:7px;border-radius:50%;background:var(--cyan)}.event b{display:block;color:#d8e8e7;font-size:11px;margin-bottom:3px}.legend{margin-top:14px;padding-top:12px;border-top:1px solid var(--line);display:flex;justify-content:space-between;font-size:9px;color:var(--muted)}.empty{padding:40px;text-align:center;color:var(--muted);border:1px dashed var(--line);border-radius:18px;grid-column:1/-1}@keyframes pulse{50%{opacity:.35;transform:scale(.8)}}
@media(max-width:920px){.layout{grid-template-columns:1fr}.ai-panel{position:relative;top:0}.kpis{min-width:0;width:100%}.hero-main{align-items:flex-start;flex-direction:column}.chain{grid-template-columns:repeat(2,1fr)}}@media(max-width:620px){.app{padding:12px}.hero{padding:18px;border-radius:18px}.kpis{grid-template-columns:repeat(3,1fr)}.kpi{padding:10px}.kpi b{font-size:21px}.sensor-grid{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(3,1fr)}.chain{grid-template-columns:1fr 1fr}.hero p{font-size:12px}.toolbar{align-items:flex-start}}
</style></head><body><main class="app">
<section class="hero"><div class="topline"><span class="brand">AI SENSOR FUSION · BIMBase</span><span class="live"><i class="dot"></i>模型数据通道在线</span></div><div class="hero-main"><div><h1>全屋传感器的 <span>AI 感知中枢</span></h1><p>把 BIMBase 模型中的环境、安全、行为与光照传感器汇聚为一条可解释的 AI 推理链：持续识别异常、判断影响空间，并给出可确认的联动建议。</p></div><div class="kpis"><div class="kpi"><b id="totalKpi">0</b><span>传感器实例</span></div><div class="kpi"><b id="onlineKpi">0</b><span>在线 / 参考</span></div><div class="kpi"><b id="riskKpi">0</b><span>AI 关注项</span></div></div></div><div class="chain"><div><b>01</b>BIM 数据采集</div><div><b>02</b>多源融合校验</div><div><b>03</b>AI 异常推断</div><div><b>04</b>生成联动建议</div></div></section>
<div class="toolbar"><div class="filters"><button class="btn active" data-floor="all">全部</button><button class="btn" data-floor="f1">一层</button><button class="btn" data-floor="f2">二层</button><button class="btn" data-floor="f3">三层</button><button class="btn" data-floor="yard">庭院</button></div><button class="btn btn-alert" id="injectBtn">⚡ 注入燃气异常演示</button></div>
<div class="layout"><section class="sensor-grid" id="sensorGrid"></section><aside class="ai-panel"><div class="ai-title"><div class="ai-orb">AI</div><div><h2>融合诊断</h2><p id="dataMode"></p></div></div><div class="score"><div class="score-line"><span>模型健康评分</span><span>置信度 <b id="confidence">96%</b></span></div><strong id="healthScore">98</strong><span style="font-size:11px;color:var(--muted)"> / 100</span><div class="meter"><i id="scoreMeter"></i></div></div><div class="insight" id="insight"></div><div class="events"><h3>AI 推理过程</h3><div id="events"></div></div><div class="legend"><span id="updateTime"></span><span>本地规则引擎 · 可解释</span></div></aside></div>
</main><script>const PAYLOAD=__PAYLOAD__;
let sensors=JSON.parse(JSON.stringify(PAYLOAD.sensors)),activeFloor='all',injected=false;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const floorName=f=>({f1:'一层',f2:'二层',f3:'三层',yard:'庭院'}[f]||'未定位');
const riskText=r=>({normal:'正常',warning:'关注',critical:'高风险'}[r]||r);
function render(){const visible=sensors.filter(s=>activeFloor==='all'||s.floor===activeFloor);const grid=document.getElementById('sensorGrid');grid.innerHTML=visible.length?visible.map(s=>`<article class="sensor ${esc(s.risk)}"><div class="card-head"><div class="identity"><small>${esc(s.code)} · ${esc(s.kind)}</small><h3>${esc(s.name)}</h3><p>${esc(floorName(s.floor))} / ${esc(s.space)} · ${esc(s.source)}</p></div><span class="risk">${esc(riskText(s.risk))}</span></div><div class="metrics">${s.metrics.slice(0,3).map(m=>`<div class="metric"><span>${esc(m.label)}</span><b>${esc(formatValue(m.value))}</b><em>${esc(m.unit)}</em></div>`).join('')}</div><div class="bars">${s.trend.map(v=>`<i style="height:${Math.max(8,Math.min(100,v))}%"></i>`).join('')}</div><div class="status-row"><span><i class="dot" style="color:var(--green)"></i><strong>${esc(s.state)}</strong></span><span>${esc(s.ai)}</span></div></article>`).join(''):'<div class="empty">当前楼层暂未布置传感器</div>';updateAI();}
function formatValue(v){return Number.isInteger(Number(v))?String(v):Number(v).toFixed(2)}
function updateAI(){const risks=sensors.filter(s=>s.risk!=='normal'),critical=risks.filter(s=>s.risk==='critical'),score=Math.max(62,98-risks.length*9-critical.length*11);document.getElementById('totalKpi').textContent=sensors.length;document.getElementById('onlineKpi').textContent=PAYLOAD.realCount+'/'+sensors.length;document.getElementById('riskKpi').textContent=risks.length;document.getElementById('dataMode').textContent=PAYLOAD.dataMode;document.getElementById('confidence').textContent=PAYLOAD.aiConfidence+'%';document.getElementById('healthScore').textContent=score;document.getElementById('scoreMeter').style.width=score+'%';const insight=document.getElementById('insight');insight.className='insight'+(critical.length?' alert':'');insight.innerHTML=critical.length?`<b>检测到高风险异常</b><br>${esc(critical[0].space)}的${esc(critical[0].name)}超过安全阈值。建议立即关闭燃气阀、启动强排风，并向家庭负责人推送确认。`:`<b>全屋感知状态稳定</b><br>AI 已完成 ${sensors.length} 类传感数据交叉验证。当前未发现需要立即处置的组合异常，继续保持低功耗巡检。`;const events=critical.length?[['浓度突增识别','天然气浓度连续上升并超过 8%LEL'],['空间影响判断','异常位于厨房，关联灶具与排风系统'],['联动方案生成','关阀 → 强排风 → 灯光提示 → 通知家人']]:[['数据融合完成',`${sensors.length} 类传感器完成时间戳与空间校验`],['异常模式比对','烟雾、燃气、水浸与环境组合均未命中风险模式'],['场景持续优化','依据自然光和人体存在状态保持节能策略']];document.getElementById('events').innerHTML=events.map(e=>`<div class="event"><b>${esc(e[0])}</b>${esc(e[1])}</div>`).join('');document.getElementById('updateTime').textContent='更新 '+new Date().toLocaleTimeString('zh-CN',{hour12:false});}
document.querySelectorAll('[data-floor]').forEach(btn=>btn.onclick=()=>{document.querySelectorAll('[data-floor]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');activeFloor=btn.dataset.floor;render()});document.getElementById('injectBtn').onclick=()=>{injected=!injected;const gas=sensors.find(s=>s.code==='SEN-03');if(injected){gas.metrics[0].value=12.6;gas.state='浓度快速上升';gas.risk='critical';gas.trend=[8,12,18,28,43,61,82,100];document.getElementById('injectBtn').textContent='✓ 恢复正常数据'}else{gas.metrics[0].value=.8;gas.state='正常';gas.risk='normal';gas.trend=[8,9,10,9,11,12,11,10];document.getElementById('injectBtn').textContent='⚡ 注入燃气异常演示'}render()};setInterval(()=>{if(!injected){sensors.forEach(s=>{if(['SEN-01','SEN-07'].includes(s.code)){s.metrics[0].value=Number((Number(s.metrics[0].value)+(Math.random()-.5)*.35).toFixed(2));s.trend.shift();s.trend.push(45+Math.round(Math.random()*22))}});render()}},3200);render();</script></body></html>'''


def save_dashboard(payload):
    os.makedirs(EXPORT_DIRECTORY, exist_ok=True)
    safe_json = json.dumps(payload, ensure_ascii=False).replace("<", "\\u003c")
    with open(JSON_PATH, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=2)
    with open(HTML_PATH, "w", encoding="utf-8") as stream:
        stream.write(HTML_TEMPLATE.replace("__PAYLOAD__", safe_json))


def dashboard_route(marker):
    return "file:///{}?v={}".format(
        HTML_PATH.replace("\\", "/"), marker
    )


def open_dashboard(marker):
    from embedded_nav import open_embedded
    open_embedded(dashboard_route(marker), "AI 传感器总览")


def main():
    marker = str(int(time.time() * 1000))
    log_event("AI 传感器总览按钮已触发 [{}]".format(marker))
    try:
        # 先保证缓存页面存在并立即发出导航，让点击始终有可见反馈。
        if not os.path.exists(HTML_PATH):
            baseline = []
            for item in SENSOR_CATALOG:
                sensor = copy.deepcopy(item)
                sensor["instance"] = sensor["code"] + "-REF"
                sensor["risk"] = risk_for(sensor)
                for metric in sensor["metrics"]:
                    metric.pop("keys", None)
                baseline.append(sensor)
            save_dashboard(build_payload(baseline))
        open_dashboard(marker + "-cached")

        sensors = scan_model_sensors()
        payload = build_payload(sensors)
        save_dashboard(payload)
        log_event("仪表盘已生成：{}，共 {} 个传感器条目".format(HTML_PATH, len(sensors)))
        open_dashboard(marker + "-fresh")
    except Exception as error:
        log_event("生成仪表盘失败：" + repr(error))
        if os.path.exists(HTML_PATH):
            try:
                open_dashboard(marker + "-fallback")
                return
            except Exception:
                pass
        ctypes.windll.user32.MessageBoxW(None, "AI 传感器总览打开失败：\n" + str(error),
                                        "智居慧脑", 0x10 | 0x50000)


# BIMBase 的 Python 按钮加载方式可能是 exec 或模块导入；两种方式都必须执行。
main()

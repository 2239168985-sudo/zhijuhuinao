# -*- coding: utf-8 -*-
"""向 BIMBase 内的智居慧脑 WebView2 面板发送导航请求。"""

import ctypes
import os
import time


BRIDGE_RUNTIME = r"D:\WorkBuddy\zhijuhuinao\bimbase-plugin-csharp\runtime"
NAVIGATION_PATH = os.path.join(BRIDGE_RUNTIME, "embedded-navigation.txt")
ACK_PATH = os.path.join(BRIDGE_RUNTIME, "embedded-navigation.ack")
READY_PATH = os.path.join(BRIDGE_RUNTIME, "embedded-panel.ready")
LOG_PATH = os.path.join(BRIDGE_RUNTIME, "python-navigation.log")


def _message(text, title="智居慧脑 · 内嵌网页", icon=0x40):
    ctypes.windll.user32.MessageBoxW(None, str(text), title, icon | 0x50000)


def _log(text):
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as stream:
            stream.write("[{}] {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S"), text))
    except Exception:
        pass


def _write_navigation(route, request_id):
    temporary = NAVIGATION_PATH + ".{}.tmp".format(os.getpid())
    with open(temporary, "w", encoding="utf-8") as stream:
        stream.write(str(route) + "\n" + request_id)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, NAVIGATION_PATH)


def _reliable_bridge_ready():
    try:
        with open(READY_PATH, "r", encoding="utf-8") as stream:
            return stream.readline().strip() == "2"
    except Exception:
        return False


def _acknowledged(request_id):
    try:
        with open(ACK_PATH, "r", encoding="utf-8") as stream:
            return stream.readline().strip() == request_id
    except Exception:
        return False


def open_embedded(route, title):
    try:
        os.makedirs(BRIDGE_RUNTIME, exist_ok=True)
        request_id = "{}-{}".format(int(time.time() * 1000), os.getpid())
        _write_navigation(route, request_id)

        if os.path.exists(READY_PATH):
            _log("已发送导航：{} -> {} [{}]".format(title, route, request_id))
            if _reliable_bridge_ready():
                for attempt in range(2):
                    deadline = time.time() + 1.25
                    while time.time() < deadline:
                        if _acknowledged(request_id):
                            _log("导航已确认：{} [{}]".format(title, request_id))
                            return
                        time.sleep(0.05)
                    if attempt == 0:
                        _log("导航尚未确认，自动重发：{} [{}]".format(title, request_id))
                        _write_navigation(route, request_id)
                _message(
                    "已发送“{}”，但内嵌面板没有确认。\n\n"
                    "请再点击一次；如果仍无响应，请保存模型并重启 BIMBase。".format(title),
                    icon=0x30,
                )
        else:
            _log("导航已写入，但内嵌面板尚未就绪：{}".format(route))
            _message(
                "导航请求已发送，但内嵌面板尚未就绪。\n\n"
                "请保存模型并完全重启 BIMBase；重启后面板会自动显示。",
                icon=0x30,
            )
    except Exception as error:
        _log("导航失败：{} -> {}".format(route, error))
        _message("无法发送内嵌网页导航请求：\n" + str(error), icon=0x10)
